
                                                                          
                                                                            
           *******************************************************************           
           *                        File setting by GioppyGio�               *           
           *******************************************************************           
                              
            --- C'� un solo bene: il sapere. E un solo male: l'ignoranza. ---                                                          
                                                                                         
                                        \|||/                                            
                   .-.________          (o o)                    ________.-.                    
              ----/ \_)_______)  +-oooO--(_)------------------+ (_______(_/ \----               
                 (    ()___)     |       Prego Visitate:      |    (___()     )                  
                      ()__)      |                            |     (__()                        
              ----\___()_)       |  https://gioppygio.net/    |      (_()___/----                
                                 +------------Ooo-------------+                                  
                              
                           
                                                           
       @************************************************************************@           |                         https://twitter.com/GioGioppy                  |
       |          https://www.facebook.com/GioppyGio-Setting-1198590176901288/  |           |                      https://gioppygio.net/                            |   
       @************************************************************************@        
                      liste canali sviluppate con l'ausilio di E-Channelizer                                        
                                                                                         
              *****************************************************************               
              *                   https://gioppygio.net/                      *               
              ***************************************************************** 

                           Saluti a tutti voi 
                                                     By GioppyGio�

                             

                                  /T /I                    
                                 / |/ | .-~/               
                             T\ Y  I  |/  /                   
            /T               | \I  |  I  Y.-~/               
           I l   /I       T\ |  |  l  |  T  /               
        T\ |  \ Y l  /T   | \I  l   \ `  l Y                  
    __  | \l   \l  \I l __l  l   \   `  _. |                
    \ ~-l  `\   `\  \  \\ ~\  \   `. .-~   |               
     \   ~-. "-.  `  \  ^._ ^. "-.  /  \   |               
   .--~-._  ~-  `  _  ~-_.-"-." ._ /._ ." ./               
    >--.  ~-.   ._  ~>-"    "\\   7   7   ]                
   ^.___~"--._    ~-{  .-~ .  `\ Y . /    |                
    <__ ~"-.  ~       /_/   \   \I  Y   : |                
      ^-.__           ~(_/   \   >._:   | l_____          
          ^--.,___.-~"  /_/   !  `-.~"--l_ /     ~"-.      
                 (_/ .  ~(   /'     "~"--,Y   -=b-. _)    
                  (_/ .  \  :           / l      c"~o \     
                   \ /    `.    .     .^   \_.-~"~--.  )    
                    (_/ .   `  /     /       !       )/      
                     / / _.   '.   .':      /        '        
                     ~(_/ .   /    _  `  .-<_                 
                       /_/. ' .-~" `.  / \  \          ,z=.    
                       ~( /   '  :   | K   "-.~-.______//  
                         "-,.    l   I/ \_    __{--->._(==.
                          //(     \  <    ~"~"     //      
                         /' /\     \  \     ,v=.  ((       
                       .^. / /\     "  }__ //===-  `       
                      / / ' '  "-.,__ {---(==-             
                    .^ '       :  T  ~"   ll               
                   / .  .  . : | :!        \\              
                  (_/  /   | | j-"          ~^             
                    ~-<_(_.^-~"                   
          
MMMMMMMMMMMMMMMMMMMMMMMMBBB0ZMMMMMMMMMMMMMMMMMMMMMMMMMMMZZ WWiMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMM@i      rZZ:8MMMMMMMMMMMMMMMMMMMMMMMMMMM2a MW MMMMMMMMM@      7aMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMi   ,r;SBWMMMa7MMMMMMMMMMMMMMMMMMMMMMMMMMMM8B M0 MMMMMMMM  8MMMMMBriZMMMMMMMMMMMMMMMMMM
MMMMMMMMMM;   i2ir2BMMMMMB 8MMMMMMMMMMMMMMMMMMMMMMMMMMMM08 MMiMMMMMMM.iMMMMMM@MMW7ZMMMMMMMMMMMMMMMMM
MMMMMMMM   2Si:0MMMMMMMM   MMMMMMMMMMM       M        ,.   ; ZM MMMM        MMMMMM0MMMMMMMMMMMMMMMMM
MMMMMW   ZriZMMMMMMMM   7:WMMMa7    M    ZM   M   WM    M    MM       0MMi:    M   MMMMMMMMMMMMMMMMM
MMMM: ,W2XMMMMMMM      rMZ MM       MM   MM   M   MMM   M@   MM  MM   MBMMMMS  M   MMMMMMMMMMMMMMMMM
MM0.;BWWMMMMMMi   WMM      M.  MM,  MM   MM   M    M    MB      MMM   MB,:     MMMMMMMMMMMMMMMMMMMMM
M2i8W@MMMZX2MS  ;MM@2:     M   .M:  MM       XM       MMM0 X   MMMM   ZMMMa0   ;r. MMMMMMMMMMMMMMMMM
8X00@0:  ;0M,  @MM     M0  MM      MMM   BrMMMM   MMMM0 MM M  rM@MMMi   MMMM   W   MMMMr   ,iS@MMMMM
ZZXZ2;r7aMMM: MMMMMMZ  M;   WM   iMMWa   MMMMM      MBS M     MW8XSMMM     M  .M   Mi   MMMMMWaZMMMM
@M2   ZMMMM   MMMMMM:     @@WWMMMMMr      MMMMMMMMMBMBa MW  MBMr;S000BMMMM     M   M      MMB08Z@MMM
X  7MMMMMMM     :,    MMMMB02X77MMMB7;8MMMM8@MMMMMMMB87 2M MMSM;Z22200WBMMMMMMM   .M  7M   M@@Wa@MMM
7MMMMMMMMMMS       :MMMMMMMMMMMMBX    XZ00MMZMMMMMMMWMMBWW MZXM:2MMW080808a0MMMMi   r  MM  Z0  7MMMM
MMMMMMMMMM@MMMMMMMMMMW00BBBB8Z@MMMMM082@W@0B8@MMMMMMMMZ ZW MZ0M r7XBMM@@B0W0ZaBMMMMMM       ,ZMMMMMM
MMMMMMM2;rri:ZMM@WWWBBWBB0BBZMMMS;;   aM@MMMBWMMMM@WW@; WW 0ZMM rWWZa8BMWW@W0W@MWMMMMM8   ,MMMMMMMMM
MMMMM. .   ZMMWBB00BBBB0BBB8MMa287ra: i80BWMMMMMMMMMaZ7ZM8 XBXM riX0@B080B@@BB022880MMMMMMMMZa8MMMMM
MM8     8MMMWBBB00B0000B800MM.8B:ZMZX8BW@B@MWMMMMMW:ii;MMa ;MaM,S@0aS2WWWB8a8WM@W0ZZ2aZ@MM@0BW08BMMM
M;,. i@MMWBBB00B0B0BBBBBB0BB aM 8M7280WBM@BMMMMMMW0MMMM00Z rMMM.2aZWW8a80BMMWa7S8MMMMW82S8MMMM@B80WM
XXrXMMMW00000B00B00B0B0B0ZMZMM rM7iWMMMMMMMMWMMMMMMMM@MM@S :MM0SrXZZB@MBZ8Z0@MMW0X2a8BBMW8aaBMMMM@0W
00WMMW00B0BBBBBBWWW0B0B0ZW8SM8 M@:M@MM8MMMZ0ZZBrWWMMMMMMWX rMMZZMWZZW02BM@Z8ZZ8B@M@WBW8WB@@MBSS8MMMM
0WBB0000BB080BWM8X0W00088M0MM @M;aM8M0i Xi        . aMMM@S ;MMWiaWMMa8MB2Z@MMWB00WMM@WM@@MMWBMM@08WM
B0B00B0000W@MWX,rX7a000aB@WMZrMM8MMMMMB0MMWBX7ii;Xriii8MMX MMXM822ZWM@8aMM072@MBBZaZBM@WB0BBWW@MMMMM
0000808B@M@Si;r8BW8BB802WZWMaMM28M@MMX . BBZ0M@SrX;022;0MS MM WMMWaa0WM@8S8MW;,i2a8ZSXS8BWMW88BW@WWM
00880WMM8,;:.aMMMa80W00ZMZ@@aMZSMMWMMB;   ,0i r80@a87.  M2 MM 0MS@MMZa8W@M87iaMMMM@W@MMMMMMMMM0SSZ@@
000WMMX    7MMMMM0S80ZaZMaM0BM7@M@BMMMMMMMi 0aZi 8Si  ZMM2 MM.ZMMS:ZMMM80BMMMZ  i0MMMB0XSZBBWMMM@8a0
0WMM; ,  BMMMMMMMMB08808MZW80ZSMMM0M0 .   XMMMMMBrMMMMBrZZ MM2iMMMMS.BMMWW88MMMM@Z778@MMMarZWWB@MMM0
@MX : :MMMMMMMMM8aZZZ@@88@@0@72@BWBMMr::iXMBr;: 2BMMMMMMMa MMMiMB0MMMX0MM@MW;rBMMMMMBZ2aBMMBZB@WBMMM
@.   WMMMMMMMMS7X,i8W8ZZ2BWWM:B@88BMM: X2,       iMMM  SM8 MMM,MM@B0MMMSBWS8@M2   7@MMMM@0ZB0a0@BW@W
;  BMMMMMMMM  i 7MM888002WMMM,W@808MM0.  X7Xrr8; 2MM Za,BZ SMM7MMMMM@B@@;0MMWB@MMM0Z080MMMMMM@WWBBWM
;rMMMMMMMM  , XMM08000002MM7MXWW880MMMWWa02X0SBX:MMMB, W@a  M@MMMMMMMMMMMiSMMM@@MMW0W@MM@@MMMMMMMBZB
XMMMMMMMS :.:MMB888888Z0ZMM MSM@00a@MMiMBaSMMa8, 0SMMMZMMSi M0MMMMMMMMMMMM WMMM@WMMMM@WW@@WW@MMMMW88
MMMMMMM    @M@800Z0WMMMM72M MSB@MMMBMMB MS;.   MZMMMMMMa8a: MZMMMMMMMMMMMM8XMMMM@8MMMMMMMMMMM@MMMM@0
MMMMM0i770MW88Z0WMMWi    7M MMBSaMMW2MM  WMMM082MMMMMMMMMZ  MXWMMMMMMMMMMMMB7BMMMW;MMMMW@MMMMMMMMMMW
Br rMB0MMM0SS082X;  .    WM MMB8;0MMMaMM0:; Sa7:WMM80MMM@Z  MaWMB@MMMMMMMMMMMXiBMB8MMMMMMMMMMM@MMMMM
.0Mi.SaZBMMMMMMW0; 7W8MB @MrMMBMX;MMMZrMMM0SX8r.  ,;MM2WW8  M28M@BZBMMMWMMMMMMM: .0MMMMMMWWWMMMMMMMM
 ,XMM7 ;:  .X.a@MMMr   Sr0Ma@MZM@ rW0MZ iMMM@. ;   XMWMMWZ  MZaMMB@BX2MMMW0WMMMMMW:i20WX:BMWB0BMMMMM
MM. ZMBi  :07 2  BMMMMBBB0@8BMXWM8 MWZ8@i ZMMMMMMMMMMMMM27 .MZZMMM0SMMiXMMMW@BWMMMM0@MMMMMMMMMM08MMM
   ;r ;MMMa, 0Z77MMMMMMMMMMB@@07MM.2M@8MBZ.7MMM@@MMMM@MMWWB MMMMMMMM7rMW:ZM@8X28@MMMZS@MMMMMMMMMMWWM
M0M@ .Z  MMMMMMMMM@:  0Z0MM@W0M 8M@:8M:WMWZ2X@MMMMMMMMMMMaS.:ZaBMMMMMB:2MMa@MM0i  ;WMMWM@WBWMMMMMMMM
7  2, rX    8  :X8@8WM7ia:7BW0M0XMMB:MMiZ0MBa8MMM@a7 . 0r .;iZrM@2@MWWMSi8MW8MMMMM8r;2ZWMMMMW0BMMMMM
Mr   7. i@a;:,:WW8S0r.8WX.SM@W@M78MM@0MW2@Z@BZZ@MMMM0MMM MMM@MXWMBMWSZMMMZ7ZBZ8MMMMMMM0Xi2@MMMM@WM@@
 r0  88  S       X@MMW; rMMMWBBM@ZMM0BWMB0M80@88@MMMMM0M:@BWBMMMMMMMMMMMMMMS;;7aWMMMMMMMMBaaBMMMMMMM
 BMi.:iM8   rSWZr:,i.iMM :MMWMB@MBBM0Z@WWWMMBZ@MM07  MMMMMMZ:MZMMMMMMMMMMMMMMMMWBWBWB8BMMMMMW0Za8WMM
  r8rr   8S   ,Z2.,rB2,BM 0WBMBBMMBMMr8MWX8MM0BW    S2;r::.        M. MMMMMMMMMMMM@r0MMZX2ZWMMMM@BMM
ai .   a@8S8aWM2 X@@0WW@M;XZMWMW@MM@MM 8M@0BMMMMS r2MSX:.   ::S0W2.S    MMMMMMMMMMMMi7MMMMMWZa8@MMMM
2W7       X@: i. aMa;;r@M M0W8MMBMMMMMW.SM@020M02i7MX:7::,WMM8aZZ8,,r2r;MMMMMMMMMMMMMrSMMMMMMM08W@MM
  .:.;;X,    .i;rZr,;X2@S0MWSr@M00MMMMMM: BWWXMZ87Xr::r,:     SX2X:XWMMMMMMMMMMMMMMMMM;rMMMMMMMM@@M@
:a@2SM87MMZ0M@S;iX8BMMM ;MMMW0 MMBBMMMWMM8 aMM2ZXXrX7rXXS:i8ZZ;S7aMMMBiMMMMMMMMMMMMMMMM:BMMMMMMMMM@M
0.rr 8r    .082MMM0ZS  8MMMBMM:aMM@MMMM@MMMB888X:7rX;rr:rS7XXM MM2rS    MMMMMMMMMMMMMMMXWM@WMMMMMMM@
, aZ: ;22Srr2r;8M@7  8MMMMMW@MW WMMMWMMM@MMMMMMMrZ7SS7X7WS MMB B    ;SS7MMMMMMMMMMMMMMMWMMM@a20MMMMM
2B7rS2WWBMMW2XMM: ,MMMMMMMMMZMM0 WMMM@MMMMMMMMMMrM;2XXMMM BM i X 8MMMMMMMMMMMMMMMMMMMMMMMM@MMMZ8Z88Z
WBX2BMMWWMMMMMaSBMMMMW@M8ZMMM@MM8XMMMMMMMMMMMM  iM2MWMBr, 0 iMMMMM2,   MMMMMMMMMMMMMMMMMMMWMMMMMMMMM
27ZMW88. XX;X.i8MMMMMZ@MaMMMMMWMM@aMMMMMW78@MSiaSW0SSa;;iiMM7Z    ;;.SMMMMMMMMMMMMMMMMMMM@8MMMMMMMMM
MMM@0WMMMM@Z72@MMMMMMZM.iMMMMMMWMMMMMBiSXi7S8MMZ .:i70B8M;X::WBXiWMMMMMMMMMMMMMMMMMMMMMMMM8rZMMMMMMM
Mr X:   ,BaX7WMMMMMMMBM0MMMMMMMMMMMS7MWMX  .i0MMM@Z2iSi2 a; :iX8Ma  iMMMMMMMMMMMMMMMMMMMMMMMX   aSi8
. :; 0WBZ,:iBMMMMMMMMa 8MMMMMMMM0  S8,.02WWr,ii08@@Mi:.8aX8MMMr; i78MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWZ
: ;88. ,M0i0MMMM   7@@,BMMMMMMMM:  MB MMB@8WXi:.X2WMMM:WW@8X:2:0@MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
S. i; MM:;MMMMMMS2W2;Z0MMMMMMMMMM: 8M , @M8BBZr,SS7Z@MaMMMMMMMMMMMMSrMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
28MMWM0.BMMMMMMMiXMM28MMMMMMMM.  7  M  BM Sa;B@8i 27W82MMBZ0Z    7,;iMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
WMZi, SMMMMM@B@2 :@MMMMM; MMMM8MMMMM8a ZZMBMMMBB20i0S7MMM@;   iXMMBSWMWBW@MMMMMMMMMMMMMMMMMMMMMMMMMM
MB7;ZMM0222Z8WMMMMMM0 ;Z   0@7; iSBa:Z@WB,,S 70WW02aB7MM iZ2MMMM@   0MMMM@W0a7S0MMMBiii7SZBW2..2BWMM
MMMMM07BMMMMMMWMMaWM, MMMM  .MS i7:r7M. aMZaZZ7ZBM800BMMMMMMMM    ,.iZMMMMMMMBZX   2XX72@MMMMWBB@MMM
MM2  :MMMMMMMa@MMMMMi2MMMZ @MM .MM 0MMM2;.@MMM WMMB@MMM        ,S8@Mr MMMMMMMMMMMMMMMMMMM2  aMMMMMMM
MZXZ@MMMMMMM@:BM8i0MMMB;iM8W   iMM  7 ,M0XMMMMMW;Z@0SSW0ZX88WMMMMMWMMMMMMMMMMMMMMMMMMMMMMMMM@Z7SBW@M
MMW@MMMMMMMMMM8WW0MMM87 Xa:XWWiZ8X:,ri2MMMMMB22WWMWZ08MMMMM08X    .7MMMMMMMMM@080B0Z2ZWWM@WMMMMMMMMM
                   


